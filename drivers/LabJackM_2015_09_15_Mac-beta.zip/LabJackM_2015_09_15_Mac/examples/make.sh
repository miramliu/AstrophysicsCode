#! /usr/bin/env sh

# Check out the SConstruct file for more info
../scons-local-2.1.0/scons.py "$@"

